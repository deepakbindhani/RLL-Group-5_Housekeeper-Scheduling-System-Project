package com.example.demo.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.AdminMaintenance;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.AdminMaintenanceRepository;


@Service
public class AdminMaintenanceImpl implements AdminMaintenanceService{
	
	
	@Autowired
	private AdminMaintenanceRepository adminMaintenanceRepository;

	@Override
	public AdminMaintenance saveAdminWorkSchedule(AdminMaintenance adminWorkSchedule) {
		return adminMaintenanceRepository.save(adminWorkSchedule);
	}

	@Override
	public List<AdminMaintenance> getAllWork() {
		return adminMaintenanceRepository.findAll();
	}

	@Override
	public AdminMaintenance getWorkById(long empid) {
		return adminMaintenanceRepository.findById(empid)
				.orElseThrow(() -> new ResourceNotFoundException("workschedule", "Id", empid));

	}

	@Override
	public AdminMaintenance updateWorkSchedule(AdminMaintenance adminWorkSchedule, long empid) {

		AdminMaintenance adminWorkScheduleDetails = adminMaintenanceRepository.findById(empid)
				.orElseThrow(() -> new ResourceNotFoundException("Workschedule", "Id", empid));

		adminWorkScheduleDetails.setHK_id(adminWorkSchedule.getHK_id());
		adminWorkScheduleDetails.setHK_name(adminWorkSchedule.getHK_name());
		adminWorkScheduleDetails.setHK_hostel(adminWorkSchedule.getHK_hostel());
		adminWorkScheduleDetails.setHK_floor(adminWorkSchedule.getHK_floor());
		adminWorkScheduleDetails.setHK_roomsCleaned(adminWorkSchedule.getHK_roomsCleaned());
		adminWorkScheduleDetails.setHK_complaints(adminWorkSchedule.getHK_complaints());
		
		
		
		adminMaintenanceRepository.save(adminWorkScheduleDetails);
		return adminWorkScheduleDetails;
	}

	@Override
	public void deleteWork(long empid) {

		adminMaintenanceRepository.findById(empid)
				.orElseThrow(() -> new ResourceNotFoundException("workschedule", "Id", empid));
		adminMaintenanceRepository.deleteById(empid);
	}
	
	

}
