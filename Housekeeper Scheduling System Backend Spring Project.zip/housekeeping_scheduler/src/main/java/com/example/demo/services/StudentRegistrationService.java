package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.StudentRegistration;

public interface StudentRegistrationService {
	
	StudentRegistration saveStudentRegistration(StudentRegistration studentRegistration);

	List<StudentRegistration> getAllStudent();

	StudentRegistration getStudentRegistrationById(long id);

}
