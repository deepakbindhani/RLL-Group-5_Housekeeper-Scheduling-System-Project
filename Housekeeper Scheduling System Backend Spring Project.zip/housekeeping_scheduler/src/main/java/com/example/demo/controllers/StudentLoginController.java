package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.StudentLogin;
import com.example.demo.services.StudentLoginService;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class StudentLoginController {
	
	@Autowired
	private StudentLoginService studentLoginService;

	public StudentLoginController(StudentLoginService studentLoginService) {
		super();
		this.studentLoginService = studentLoginService;
	}
	
	@PostMapping("/Student_Login")
	
		public ResponseEntity<StudentLogin> saveEmployee(@RequestBody StudentLogin studentLogin) 
	{
	
			return new ResponseEntity<StudentLogin>(studentLoginService.saveStudent(studentLogin), HttpStatus.CREATED);
	}
		

}
