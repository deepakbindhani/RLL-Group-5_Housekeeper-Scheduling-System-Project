package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.demo.entities.AdminLogin;
import com.example.demo.repositories.AdminLoginRepository;



@Service
public class AdminLoginImpl implements AdminLoginService{
	
	@Autowired
	private AdminLoginRepository adminLoginRepository;

	public AdminLoginImpl(AdminLoginRepository adminLoginRepository) {
		super();
		this.adminLoginRepository = adminLoginRepository;
	}

	@Override
	public AdminLogin saveAdmin(AdminLogin adminLogin) {
		return adminLoginRepository.save(adminLogin);
	}
	
	@Override
	public Boolean verifyAdmin(String name, String password)
	{
		List<AdminLogin> admins = adminLoginRepository.findAll();
		
		for(AdminLogin admin : admins)
		{
			if(admin.getName().equals(name) && admin.getPassword().equals(password)) 
			{
				return true;
			}
		}
		return false;
	}

}
