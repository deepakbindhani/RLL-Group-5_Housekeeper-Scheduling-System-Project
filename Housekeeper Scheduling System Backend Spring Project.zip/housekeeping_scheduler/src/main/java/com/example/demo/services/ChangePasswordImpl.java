package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.ChangePassword;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.ChangePasswordRepository;

@Service
public class ChangePasswordImpl implements ChangePasswordService {

	@Autowired
	private ChangePasswordRepository changePasswordRepository;

	public ChangePasswordImpl(ChangePasswordRepository changePasswordRepository) {
		super();
		this.changePasswordRepository = changePasswordRepository;
	}

	@Override
	public ChangePassword changePassword(ChangePassword changePassword, long id) {

		ChangePassword changePasswordDetails = changePasswordRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Password", "Id", id));

		changePasswordDetails.setOld_password(changePassword.getOld_password());
		changePasswordDetails.setNew_password(changePassword.getNew_password());
		changePasswordDetails.setConfirm_password(changePassword.getConfirm_password());

		changePasswordRepository.save(changePasswordDetails);
		return changePasswordDetails;
	}

}