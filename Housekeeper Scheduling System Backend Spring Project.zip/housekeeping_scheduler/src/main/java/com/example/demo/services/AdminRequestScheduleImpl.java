package com.example.demo.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.AdminRequestsSchedule;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.AdminRequestScheduleRepository;

@Service
public class AdminRequestScheduleImpl implements AdminRequestScheduleService {

	@Autowired
	AdminRequestScheduleRepository adminRequestScheduleRepository;

	public AdminRequestScheduleImpl(AdminRequestScheduleRepository adminRequestScheduleRepository) {
		super();
		this.adminRequestScheduleRepository = adminRequestScheduleRepository;
	}

	@Override
	public AdminRequestsSchedule saveAdminRequestSchedule(AdminRequestsSchedule adminRequestsSchedule) {
		return adminRequestScheduleRepository.save(adminRequestsSchedule);
	}

	@Override
	public List<AdminRequestsSchedule> getAllRequests() {
		return adminRequestScheduleRepository.findAll();
	}

	@Override
	public AdminRequestsSchedule getRequestById(long empid) {
		return adminRequestScheduleRepository.findById(empid)
				.orElseThrow(() -> new ResourceNotFoundException("Requestschedule", "Id", empid));

	}

	@Override
	public AdminRequestsSchedule updateRequestSchedule(AdminRequestsSchedule adminRequestsSchedule, long empid) {

		AdminRequestsSchedule adminRequestScheduleDetails = adminRequestScheduleRepository.findById(empid)
				.orElseThrow(() -> new ResourceNotFoundException("Workschedule", "Id", empid));

		adminRequestScheduleDetails.setEmp_name(adminRequestsSchedule.getEmp_name());
		adminRequestScheduleDetails.setHostel(adminRequestsSchedule.getHostel());
		adminRequestScheduleDetails.setFloor(adminRequestsSchedule.getFloor());
		adminRequestScheduleDetails.setFloor(adminRequestsSchedule.getFloor());
		adminRequestScheduleDetails.setComplains(adminRequestsSchedule.getComplains());

		adminRequestScheduleRepository.save(adminRequestScheduleDetails);
		return adminRequestScheduleDetails;
	}

	@Override
	public void deleteRequest(long empid) {

		adminRequestScheduleRepository.findById(empid)
				.orElseThrow(() -> new ResourceNotFoundException("Requestschedule", "Id", empid));
		adminRequestScheduleRepository.deleteById(empid);
	}

}