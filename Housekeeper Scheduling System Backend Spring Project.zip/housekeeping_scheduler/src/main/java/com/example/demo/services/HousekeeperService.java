package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.Housekeeper;

public interface HousekeeperService {
	
	Housekeeper saveEmployee(Housekeeper housekeeper);

	List<Housekeeper> getAllEmployees();

	Housekeeper getEmployeeById(long id);

	Housekeeper updateEmployee(Housekeeper employee, long id);

	void deleteEmployee(long id);
	

}
