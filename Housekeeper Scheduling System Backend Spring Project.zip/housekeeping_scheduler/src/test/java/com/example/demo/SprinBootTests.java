package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entities.AdminMaintenance;
import com.example.demo.entities.AdminRequestsSchedule;
import com.example.demo.entities.Feedback;
import com.example.demo.entities.UpdateProfile;
import com.example.demo.entities.UserAuthentication;
import com.example.demo.repositories.AdminMaintenanceRepository;
import com.example.demo.repositories.AdminRequestScheduleRepository;
import com.example.demo.repositories.FeedbackRepo;
import com.example.demo.repositories.UpdateProfileRepository;
import com.example.demo.repositories.UserAuthenticationRepo;



@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class SprinBootTests {
	
	
	//Feedback
	@Autowired
	public FeedbackRepo feedbackRepo;
	
	@Test
	@Order(1)
	public void getAllFeedbacks() {
		List<Feedback> list = feedbackRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	@Order(2)
	public Feedback Add(Feedback feedback) {
		return feedbackRepo.save(feedback);

	}
	
	// WorkSchedule
	
	@Autowired
	AdminRequestScheduleRepository ws;

	@Test
	@Order(3)
	public void saveAdminRequestSchedule() {
		AdminRequestsSchedule a = new AdminRequestsSchedule();
		a.setId(4L);
		a.setEmp_name("Dinesh");
		a.setHostel(1);
		a.setFloor(1);
		a.setRooms_cleaned("4");
		ws.save(a);
		assertNotNull(ws.findById(4L).get());
	}
	
	
	@Test
	@Order(4)
	public void getAllRequests() {
		List<AdminRequestsSchedule> list = ws.findAll();
		assertThat(list).size().isGreaterThan(0);
	
	}
	
	//Update Profile
	
	@Autowired
	UpdateProfileRepository upr;
	
	@Test
	@Order(5)
	public void saveprofile() {
		UpdateProfile up = new UpdateProfile();
		up.setName("Dinga");
		up.setRollnumber(45);
		up.setPassword("dd@1234");
		up.setFloor(2);
		up.setRoomNo(3);
		upr.save(up);
		assertNotNull(upr.findById(1L).get());
	}
	
	@Test
	@Order(6)
	public void getAllProfile() {
		List<UpdateProfile> list = upr.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	
	@Test
	@Order(7)
	public void testUpdateProfile() {
		UpdateProfile up = upr.findById(1L).get();
		up.setName("Raj");
		upr.save(up);
		assertNotEquals("Raj", upr.findById(1L).get().getName());
	}
	
	@Test
	@Order(8)
	public void testDeleteProfile() {
		upr.deleteById(1L);
		assertThat(upr.existsById(2L)).isFalse();
	}		
}
